module Snake where

    import Data.Map as Map
    
    import Data
    
    directionVectorMap = Map.fromList $ zip [UP, DOWN, LEFT, RIGHT]
                                            [(0, (-1)), (0, 1), ((-1), 0), (1, 0)]
    
    move :: Food -> Direction -> Snake -> (Bool, Snake)
    move food direction snake = if wasFoodEaten
                                then (True, newHead : snake)
                                else (False, newHead : init snake)
        where   wasFoodEaten = newHead == food
                newHead = directionVectorMap ! direction +: head snake
                (a, b) +: (c, d) = (a + c, b + d)
    
   