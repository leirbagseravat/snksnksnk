module World where


import Data.Map as Map
import System.Random

import Data

checkGameOver :: Snake -> Bool
checkGameOver snake =   headX == 0 || headX == cols ||
                        headY == 0 || headY == rows ||
                        head' `elem` tail'
    where   head' = head snake
            (headX, headY) = head'
            tail' = tail snake


initialGameState gameOver = GameState   { getSnake = [  (snakeX, snakeY),
                                                        (snakeX, snakeY - 1),
                                                        (snakeX, snakeY - 2),
                                                        (snakeX - 1, snakeY - 2),
                                                        (snakeX - 2, snakeY - 2)]
                                        , getFood = (3, 3)
                                        , getDirection = DOWN
                                        , isGameOver = gameOver
                                        , getRandomStdGen = mkStdGen 100 }
        where   snakeX = cols `div` 2
                snakeY = rows `div` 2

changeDirection :: GameState -> Direction -> GameState
changeDirection (GameState s f d g r) newDir = GameState s f newDir g r
    