module Main where


import Snake
import Food
import World
import Data

import Graphics.Gloss
import Graphics.Gloss.Interface.Pure.Game
import Debug.Trace
import Data.Char (intToDigit)



render :: GameState -> Picture
render gameState = pictures $   [ fillRectangle black (16, 0) (660, 20)
                                , fillRectangle black (16, 24) (660, 20)
                                , fillRectangle black (0, 12) (20, 480)
                                , fillRectangle black (32, 12) (20, 480)
                                ] ++
                                  fmap (convertToPicture blue) snake ++
                                  fmap (convertToPicture green) [food] ++
                                  gameOverPicture
    where   snake = getSnake gameState
            food = getFood gameState
            convertToPicture :: Color -> (Int, Int) -> Picture
            convertToPicture color' (x, y) = fillRectangle color' (toFloat (x, y)) (20, 20)
            fillRectangle color' (tx, ty) (w, h) =  color color' $
                                                    scale 1 (-1) $
                                                    translate (tx * 20 - 320) (ty * 20 - 240) $
                                                    rectangleSolid w h
            toFloat (x, y) = (fromIntegral x, fromIntegral y)
            gameOverPicture =   if (isGameOver gameState)
                                then [  color black $
                                        translate (-200) (0) $
                                        scale 0.5 0.5 $
                                        text "Novo   Jogo"
                                     ,  color black $
                                        translate (-175) (-50) $
                                        scale 0.15 0.15 $
                                        text "Pressione espaco para jogar."
                                        ,  color black $
                                        translate (-125) (-100) $
                                        scale 0.15 0.15 $
                                        text $ "Pontuacao: " ++ show(((length$snake)-5)*10)
                                        , color green $
                                        translate (-125) (-150) $
                                        scale 0.15 0.15 $
                                        text "Em jogo, aperte F1 para Reset"
                                        ]
                                else []

atualizaJogo :: Float -> GameState -> GameState
atualizaJogo segundos estado =  if (gameOver)
                            then estado
                            else GameState newSnake newFood' direction newGameOver newStdGen
    where   snake = getSnake estado
            food = getFood estado
            direction = getDirection estado
            gameOver = isGameOver estado
            stdGen = getRandomStdGen estado
            (wasFoodEaten, newSnake) = move food direction snake
            (newFood, newStdGen) = generateNewFood newSnake stdGen
            newFood' =  if wasFoodEaten
                        then newFood
                        else food
            newGameOver = checkGameOver newSnake

handleKeys :: Event -> GameState -> GameState
handleKeys (EventKey (SpecialKey KeyLeft ) Down _ _) gameState = changeDirection gameState LEFT
handleKeys (EventKey (SpecialKey KeyRight) Down _ _) gameState = changeDirection gameState RIGHT
handleKeys (EventKey (SpecialKey KeyUp   ) Down _ _) gameState = changeDirection gameState UP
handleKeys (EventKey (SpecialKey KeyDown ) Down _ _) gameState = changeDirection gameState DOWN
handleKeys (EventKey (SpecialKey KeySpace) Down _ _) gameState =    if (isGameOver gameState)
                                                                    then initialGameState False
                                                                    else gameState
handleKeys (EventKey (SpecialKey KeyF1) Down _ _) gameState =  initialGameState False
                                                                 

handleKeys _ gameState = gameState

janela :: Display
janela = InWindow "Haskell Snake Game" (920, 640) (100, 100)

fundo :: Color
fundo = white

main :: IO ()
main = play janela fundo 10 (initialGameState True) render handleKeys atualizaJogo
